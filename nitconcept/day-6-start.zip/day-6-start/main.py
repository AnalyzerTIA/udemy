# print("Hello!")
# num_char = len("Hello!")
# print(num_char)

# def my_function():
#   print("Hello!")
#   print("Bye")
# my_function()

# complex_number = 82 + 14j
# complex_number.conjugate()
# print(complex_number)

# y = hex(0x123aabbaffee)
# print(y)

# x = complex(82 + 14j)
# print(x.conjugate())

# mesaj = "Cursul de python "\
#         "Se desfasoara "\
#         "In fiecare saptamana "\
#         "Luni seara "
# print(mesaj)

# mesaj = """Salutare astazi discutam
# despre siruri de caractere
# in limbajul Python"""
# print(mesaj)

mesaj = "Salut. Cursul oncepe. "